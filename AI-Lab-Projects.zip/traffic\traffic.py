
import cv2
import numpy as np
import os
import sys
import tensorflow as tf

from sklearn.model_selection import train_test_split


EPOCHS = 10
IMG_WIDTH = 30
IMG_HEIGHT = 30
NUM_CATEGORIES = 43
TEST_SIZE = 0.4


def main():

    # Check command-line arguments
    if len(sys.argv) not in [2, 3]:
        sys.exit("Usage: python traffic.py data_directory [model.h5]")

    # Get image arrays and labels for all image files
    images, labels = load_data(sys.argv[1])

    # Split data into training and testing sets
    labels = tf.keras.utils.to_categorical(labels)
    x_train, x_test, y_train, y_test = train_test_split(
        np.array(images), np.array(labels), test_size=TEST_SIZE
    )

    # Get a compiled neural network
    model = get_model()

    # Fit model on training data
    model.fit(x_train, y_train, epochs=EPOCHS)

    # Evaluate neural network performance
    model.evaluate(x_test, y_test, verbose=2)

    # Save model to file
    if len(sys.argv) == 3:
        filename = sys.argv[2]
        model.save(filename)
        print(f"Model saved to {filename}.")


def load_data(data_dir):
    """
    Load image data from directory data_dir.

    Return tuple (images, labels).
    Images are resized to IMG_WIDTH x IMG_HEIGHT.
    Labels represent the category of each image.
    """

    images = []
    labels = []

    for category in range(NUM_CATEGORIES):

        category_dir = os.path.join(data_dir, str(category))

        for filename in os.listdir(category_dir):

            image_path = os.path.join(category_dir, filename)

            # Read image
            image = cv2.imread(image_path)

            if image is None:
                continue

            # Resize image
            image = cv2.resize(image, (IMG_WIDTH, IMG_HEIGHT))

            # Convert from OpenCV BGR to RGB
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            images.append(image)
            labels.append(category)

    return images, labels


def get_model():
    """
    Returns a compiled convolutional neural network model.
    """

    model = tf.keras.models.Sequential([

        # Normalize pixel values from 0-255 to 0-1
        tf.keras.layers.Rescaling(
            1.0 / 255,
            input_shape=(IMG_WIDTH, IMG_HEIGHT, 3)
        ),

        # First convolutional layer
        tf.keras.layers.Conv2D(
            32,
            (3, 3),
            activation="relu"
        ),

        # First pooling layer
        tf.keras.layers.MaxPooling2D(
            pool_size=(2, 2)
        ),

        # Second convolutional layer
        tf.keras.layers.Conv2D(
            64,
            (3, 3),
            activation="relu"
        ),

        # Second pooling layer
        tf.keras.layers.MaxPooling2D(
            pool_size=(2, 2)
        ),

        # Convert feature maps into a single vector
        tf.keras.layers.Flatten(),

        # Hidden layer
        tf.keras.layers.Dense(
            128,
            activation="relu"
        ),

        # Reduce overfitting
        tf.keras.layers.Dropout(0.5),

        # Output layer: one unit per traffic sign category
        tf.keras.layers.Dense(
            NUM_CATEGORIES,
            activation="softmax"
        )
    ])

    model.compile(
        optimizer="adam",
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )

    return model


if __name__ == "__main__":
    main()
